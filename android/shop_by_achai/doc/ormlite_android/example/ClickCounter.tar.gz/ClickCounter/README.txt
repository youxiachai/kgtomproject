-------------------------------------------------------------------------------------------------------

BACKGROUND:

This example application is a demonstration of ORMLite and implements a little "click counter" application. 

For more information, see the online documentation on the home page:

   http://ormlite.com/

Enjoy,
Gray Watson

-------------------------------------------------------------------------------------------------------
