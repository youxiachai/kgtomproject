-------------------------------------------------------------------------------------------------------

BACKGROUND:

This is a little HelloWorld type of application that demonstrates how to use ORMLite. 

For more information, see the online documentation on the home page:

   http://ormlite.com/

Enjoy,
Gray Watson

-------------------------------------------------------------------------------------------------------
