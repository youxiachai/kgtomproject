-------------------------------------------------------------------------------------------------------

BACKGROUND:

This is a HelloWorld application similar to HelloAndroid but it uses the unsupported JDBC interface
to connect to the supplied H2 database instead of the SQLite database built into Android. 

For more information, see the online documentation on the home page:

   http://ormlite.com/

Enjoy,
Gray Watson

-------------------------------------------------------------------------------------------------------
