-------------------------------------------------------------------------------------------------------

BACKGROUND:

This is an example application that demonstrates how to use ORMLite in a service type of application. 

For more information, see the online documentation on the home page:

   http://ormlite.com/

Enjoy,
Gray Watson

-------------------------------------------------------------------------------------------------------
