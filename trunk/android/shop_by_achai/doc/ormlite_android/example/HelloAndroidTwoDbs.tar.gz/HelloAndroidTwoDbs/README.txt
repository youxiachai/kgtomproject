-------------------------------------------------------------------------------------------------------

BACKGROUND:

This is an application similar to HelloAndroid but it supports two
databases and manages the helper on its own.

For more information, see the online documentation on the home page:

   http://ormlite.com/

Enjoy,
Gray Watson

-------------------------------------------------------------------------------------------------------
